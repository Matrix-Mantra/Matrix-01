"""Gemini calls: Nepali speech recognition, triage, and report writing.

All model outputs that the app relies on are requested as JSON with a schema, so the code never
has to guess what the model meant.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from functools import lru_cache
from pathlib import Path
from typing import Literal

from google import genai
from google.genai import types
from pydantic import BaseModel, Field

from . import config

Urgency = Literal["emergency", "urgent", "soon", "routine"]
Department = Literal["emergency", "general_medicine", "general_surgery", "cardiology", "neurology", "neurosurgery",
                     "orthopedics", "obstetrics_gynecology", "pediatrics", "ophthalmology", "ent", "dermatology",
                     "psychiatry", "oncology", "nephrology", "gastroenterology", "pulmonology", "urology", "dental",
                     "burns"]


@lru_cache(maxsize=1)
def client() -> genai.Client:
    return genai.Client()


def _json_call(model: str, contents: list, schema: type[BaseModel], temperature: float = 0.2) -> BaseModel:
    resp = client().models.generate_content(
        model=model,
        contents=contents,
        config=types.GenerateContentConfig(temperature=temperature, response_mime_type="application/json",
                                           response_schema=schema),
    )
    if getattr(resp, "parsed", None) is not None:
        return resp.parsed
    return schema.model_validate(json.loads(resp.text))


# ------------------------------------------------------------------ speech


GEMINI_AUDIO = {"audio/wav", "audio/x-wav", "audio/mp3", "audio/mpeg", "audio/aiff", "audio/aac", "audio/ogg", "audio/flac"}


def to_supported_audio(data: bytes, mime_type: str) -> tuple[bytes, str]:
    """Browsers record webm/mp4; convert to 16 kHz mono WAV with ffmpeg."""
    base = (mime_type or "").split(";")[0].strip().lower()
    if base in GEMINI_AUDIO:
        return data, base
    if not shutil.which("ffmpeg"):
        raise RuntimeError("ffmpeg is not installed")
    with tempfile.TemporaryDirectory() as tmp:
        src, dst = Path(tmp) / "in", Path(tmp) / "out.wav"
        src.write_bytes(data)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(src), "-ac", "1", "-ar", "16000", str(dst)],
                       check=True, timeout=60)
        return dst.read_bytes(), "audio/wav"


TRANSCRIBE_PROMPT = """\
Transcribe this voice recording exactly as spoken. The speaker is most likely speaking Nepali, possibly
mixed with English, Maithili, Bhojpuri, Tharu or Newari words. Write Nepali in Devanagari script.
Do not translate, summarise, correct or add anything. Return only the transcript.
If there is no clear speech, return an empty string."""


def transcribe(data: bytes, mime_type: str) -> str:
    audio, mime = to_supported_audio(data, mime_type)
    resp = client().models.generate_content(
        model=config.SPEECH_MODEL,
        contents=[types.Part.from_bytes(data=audio, mime_type=mime), TRANSCRIBE_PROMPT],
        config=types.GenerateContentConfig(temperature=0.0),
    )
    return (resp.text or "").strip()


# ------------------------------------------------------------------ step 1: triage


class Triage(BaseModel):
    is_health_problem: bool = Field(description="False if the text does not describe a health problem or need.")
    patient: str = Field(description="Who is sick and their age if mentioned, e.g. 'father, 62'. Empty if unknown.")
    key_symptoms: list[str] = Field(description="Main symptoms in short words, in the transcript's language.")
    duration: str = Field(description="How long it has been happening, if mentioned. Empty if unknown.")
    urgency: Urgency
    department: Department = Field(description="The single best hospital department to visit first.")
    alternative_department: str = Field(description="A second suitable department from the same list, or empty.")
    district_mentioned: str = Field(description="Nepal district or city the speaker says they are in, in English. Empty if none.")
    cost_worry: bool = Field(description="True if the speaker worries about money or mentions being poor.")


TRIAGE_PROMPT = """\
You help people in Nepal find the right hospital department. You are NOT a doctor and must not diagnose.
Read what the person said (it may be Nepali, romanized Nepali or English, and may contain speech-recognition
mistakes) and fill in the fields.

Urgency rules:
- emergency: danger signs now (chest pain, severe breathing trouble, unconscious, fits, stroke signs, heavy
  bleeding, pregnancy bleeding or severe pain, snake bite, poisoning, serious injury or burn, suicidal thoughts,
  a baby who is not feeding or is very weak). department must then be "emergency".
- urgent: should see a doctor today (e.g. high fever for 3+ days, severe pain, child with fever and not eating).
- soon: within a few days. routine: a normal OPD visit is fine.
When unsure between two levels, choose the more urgent one.
Department: choose where a patient in Nepal would normally go FIRST. Use general_medicine for unclear adult
problems and pediatrics for children under 15.

What the person said:
\"\"\"{text}\"\"\""""


def triage(text: str) -> Triage:
    return _json_call(config.TRIAGE_MODEL, [TRIAGE_PROMPT.format(text=text)], Triage, temperature=0.1)


# ------------------------------------------------------------------ step 2: report


class Pick(BaseModel):
    hospital_id: str = Field(description="Must be one of the candidate ids.")
    why: str = Field(description="One short sentence: why this hospital (distance, department, insurance, ratings).")


class ReportText(BaseModel):
    title: str = Field(description="Short title, e.g. 'Chest pain: go to the emergency department now'.")
    summary: str = Field(description="2-3 simple sentences: what the person told us and what we suggest.")
    urgency_reason: str = Field(description="One sentence on why this level of urgency.")
    do_now: list[str] = Field(description="2-4 short, practical steps to take now, most important first.")
    department_reason: str = Field(description="One sentence: why this department, in plain words.")
    picks: list[Pick] = Field(description="1-3 hospitals from the candidates, best first.")
    what_to_bring: list[str] = Field(description="3-6 things to bring (ID, insurance card, old reports, medicines...).")
    questions_for_doctor: list[str] = Field(description="2-4 simple questions to ask the doctor.")
    warning_signs: list[str] = Field(description="2-4 signs that mean go to emergency immediately.")
    travel_tip: str = Field(description="One practical tip about getting there or timing. Empty if nothing useful.")


REPORT_PROMPT = """\
You write a short, clear hospital visit guide for a person in Nepal who may have little education.
Write ALL text in {language}. Use simple everyday words and short sentences. Explain any medical word you use.

STRICT RULES
- You are not a doctor. Do not diagnose or name a disease the person might have. Do not suggest medicines or doses.
- Choose hospitals ONLY from the candidate list, by id. Do not invent hospitals, phone numbers, prices, doctors
  or opening hours. Prefer closer hospitals; for a non-emergency also consider government hospitals and health
  insurance acceptance; use ratings only as a tie-breaker.
- If urgency is emergency, the first do_now step must be to call 102 for an ambulance or go to the nearest
  emergency department right now.
- If a nearest_general hospital is given and the problem is not an emergency, mention in do_now or travel_tip
  that they can be examined there first and get a referral.

What the person said: \"\"\"{text}\"\"\"
Triage: {triage}
Department to visit: {department} ({department_label})
Person's location: {origin}
Candidate hospitals (JSON): {candidates}
Nearest general hospital (JSON, may be null): {nearest_general}"""


def write_report(*, text: str, triage_result: Triage, department: str, department_label: str, origin_label: str,
                 candidates: list[dict], nearest_general: dict | None, lang: str) -> ReportText:
    slim = lambda h: None if h is None else {  # noqa: E731
        k: h.get(k) for k in ("id", "name", "type_label", "city", "district", "distance_km", "emergency_24h",
                              "health_insurance", "rating")
    }
    prompt = REPORT_PROMPT.format(
        language="simple Nepali (Devanagari script)" if lang == "ne" else "simple English",
        text=text, triage=triage_result.model_dump_json(), department=department, department_label=department_label,
        origin=origin_label or "unknown", candidates=json.dumps([slim(c) for c in candidates], ensure_ascii=False),
        nearest_general=json.dumps(slim(nearest_general), ensure_ascii=False),
    )
    return _json_call(config.REPORT_MODEL, [prompt], ReportText, temperature=0.3)
